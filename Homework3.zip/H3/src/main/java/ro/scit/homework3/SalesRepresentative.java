package main.java.ro.scit.homework3;

public class SalesRepresentative {
    /**
     * Class for sales representatives
     */
    String name;
    String department;
    int sales;
    int quota;
    int revenue;
}
