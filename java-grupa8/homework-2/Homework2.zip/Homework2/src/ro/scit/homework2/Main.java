package ro.scit.homework2;

import java.util.Scanner;

import static ro.scit.homework2.Sort.bubbleSort;

public class Main {

    public static void main(String[] args) {
        String names[] = {"John", "Marc", "David", "Oliver"};
        int sales[] = {10, 7, 3, 10};
        int quota[] = {500, 800, 1500, 300};
        int revenue[] = new int[4];

        for (int i = 0; i < names.length; i++) {
            revenue[i] = sales[i] * quota[i];
            System.out.println("The revenue for " + names[i] + " is " + revenue[i]);
        }

        bubbleSort(revenue, names);

        System.out.println("After Bubble Sort");

        for (int i = 0; i < names.length; i++) {
            System.out.println("The revenue for " + names[i] + " is " + revenue[i]);
        }
    }
}
